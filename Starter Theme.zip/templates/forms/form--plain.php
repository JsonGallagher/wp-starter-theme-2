<form>
	<label>First Name</label>
	<input type="text">

	<label>Last Name</label>
	<input type="text">

	<label>Message</label>
	<textarea></textarea>

	<input type="submit" value="Send">

</form>