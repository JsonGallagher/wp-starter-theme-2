<header class="page-header">
	<div class="row">
		<h1 class="page-header__title"><?php _e( $title, 'starter-theme' ); ?></h1>
	</div>
</header>