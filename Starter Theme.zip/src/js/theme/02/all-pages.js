function pageActions() {
	// nav stuff
	stickyNav();
	mobileNav();

	// go to top button
	goToTop();

	// form inputs, validation, submit intercept, etc.
	formActions();

	// lazy load images when the reach viewport
	lazyLoad();
}
