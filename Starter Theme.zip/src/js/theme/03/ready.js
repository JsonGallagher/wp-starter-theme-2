$(document).ready(function() {
	pageActions();
});
