<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package starter-theme
 */
?>

<?php include('templates/footer/footer-content.php'); ?>
</div><!-- #menu-content-->

<a href="#" class="button go-top-button"><i class="fa fa-caret-up"></i></a>

<?php wp_footer(); ?>

<?php include('templates/footer/footer-scripts.php'); ?>

</body>
</html>
